from setuptools import setup

version = '1.0'

setup(name='lacking',
      version=version,
      packages=['lacking'],
      )
